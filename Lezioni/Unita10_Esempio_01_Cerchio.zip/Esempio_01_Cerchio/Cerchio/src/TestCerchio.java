import java.util.Scanner;

public class TestCerchio {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cerchio[] cerchi = new Cerchio[5];

        // Inserimento dei raggi e creazione dei cerchi
        for (int i = 0; i < cerchi.length; i++) {
            System.out.print("Inserisci il raggio del cerchio " + (i + 1) + ": ");
            double raggio = scanner.nextDouble();
            cerchi[i] = new Cerchio(raggio); // centro all'origine
        }

        // Stampa dei perimetri
        System.out.println("\nPerimetri dei cerchi:");
        for (int i = 0; i < cerchi.length; i++) {
            System.out.printf("Cerchio %d: %.2f\n", (i + 1), cerchi[i].perimetro());
        }

        scanner.close();
    }
}
