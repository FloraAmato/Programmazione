public class Cerchio {
    // Attributi privati
    private double x;
    private double y;
    private double raggio;

    // Costruttore con raggio, centro all'origine
    public Cerchio(double raggio) {
        this.raggio = raggio;
        this.x = 0.0;
        this.y = 0.0;
    }

    // Getter e setter
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getRaggio() {
        return raggio;
    }

    public void setRaggio(double raggio) {
        this.raggio = raggio;
    }

    // Metodo per calcolare l'area
    public double area() {
        return Math.PI * raggio * raggio;
    }

    // Metodo per calcolare il perimetro
    public double perimetro() {
        return 2 * Math.PI * raggio;
    }
}
